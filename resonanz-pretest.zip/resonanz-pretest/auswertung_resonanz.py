# -*- coding: utf-8 -*-
"""
Auswertung Pretest RESONANZ
===========================
Liest den SoSci-Survey-Export ein, berechnet alle deskriptiven Kennwerte
und fasst das Ergebnis in einem fertigen Word-Dokument zusammen. Die beiden
Abbildungen werden direkt in das Word-Dokument eingebettet und nicht als
separate Bilddateien gespeichert.

Erzeugte Datei:
    RESONANZ_Auswertung_Ergebnis.docx

Voraussetzung:
    pip install openpyxl matplotlib python-docx

Hinweis zur Methodik:
    Die xlsx-Datei ist ausschliesslich das Exportformat von SoSci Survey.
    Es wurden keine Werte manuell eingetragen oder von Hand berechnet.
    Fehlende Werte werden nicht ersetzt (keine Imputation). Die Auswertung
    ist deskriptiv, da der Pretest der Konzeptpruefung dient und nicht der
    Hypothesentestung.
"""

import statistics as st
from collections import Counter
from io import BytesIO
import traceback
import os
import datetime

import openpyxl
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

# ----------------------------------------------------------------------
# 1 Einstellungen
# ----------------------------------------------------------------------

DATEI = r"Pretest_Export_soscisurvey.xlsx"
WORD_DATEI = "RESONANZ_Auswertung_Ergebnis.docx"

ITEMS = {
    "A103": "F4b Mentaler Gesundheitszustand",
    "A104": "F4c Stress im Studienalltag",
    "A201": "F5  App klingt interessant",
    "A202": "F6  App-Foerderung sinnvoll",
    "A203": "F7  Kombination Profil und Empfehlung",
    "A204": "F8  Punktesystem motiviert",
    "A205": "F8a Punkte sammeln motivierend",
    "A206": "F8b Gamification spricht an",
    "A207": "F9  Wuerde die App ausprobieren",
    "A208": "F10 Mehrwoechige Nutzung",
    "A301": "F11 Funktionsweise verstaendlich",
    "A302": "F12 Inhalte passen zum Ziel",
    "A303": "F13 Datenschutz-Bedenken (negativ gepolt)",
    "A304": "F13b Tracking bei klarem Nutzen erlauben",
    "A305": "F14 Empfehlung durch Institution",
}

SKALEN = {
    "S1 Attraktivitaet und Akzeptanz": ["A201", "A202", "A204", "A207"],
    "S2 Nutzungsintention":            ["A207", "A208"],
    "S3 Verstaendlichkeit":            ["A301", "A302"],
    "S4 Gamification-Akzeptanz":       ["A204", "A205", "A206"],
}

KATEGORIAL = {
    "A101": ("F1  Alter", {1: "18-24", 2: "25-34", 3: "35-44", 4: "45+"}),
    "A102": ("F2  Geschlecht", {1: "weiblich", 2: "maennlich", 3: "divers", 4: "keine Angabe"}),
    "A401": ("F15 Vorerfahrung", {1: "Ja", 2: "Nein", 3: "keine Angabe"}),
    "A404": ("F16b Zahlungsbereitschaft", {1: "kostenlos", 2: "bis 2 EUR", 3: "bis 5 EUR", 4: "bis 10 EUR", 5: "ueber 10 EUR"}),
    "A405": ("F16c Preismodell", {1: "Werbung", 2: "Freemium", 3: "Einmalkauf", 4: "Abo", 5: "keine Praeferenz"}),
}

OFFEN = {
    "A502_01": "F17 Was gefaellt besonders gut",
    "A503_01": "F18 Was muesste verbessert werden",
    "A504_01": "F19 Was foerdert regelmaessige Nutzung",
}

# Freitextfelder mit Namen bereits genutzter Apps (Mehrfachnennung moeglich)
APP_NENNUNGEN = ["A402x01", "A402x02"]
APP_ZUFRIEDENHEIT = "A403"   # Zufriedenheit mit bisher genutzten Apps (Skala 1-5)

# Farben (HFU-Gruen)
HFU_HEX = "00893A"
HFU_HELL = "EAF5EE"
HFU_FARBE = "#00893A"
MEDIUM = "#5FB878"
HELL = "#BEE3C8"
GRAU = "#888888"

# ----------------------------------------------------------------------
# 2 Hilfsfunktionen
# ----------------------------------------------------------------------

def lade_daten(pfad):
    if not os.path.exists(pfad):
        raise FileNotFoundError(f"Die Datei '{pfad}' wurde nicht gefunden!")
    wb = openpyxl.load_workbook(pfad, data_only=True)
    rows = list(wb.worksheets[0].iter_rows(values_only=True))
    codes = rows[0]
    idx = {c: i for i, c in enumerate(codes) if c}
    daten = rows[2:]
    return idx, daten

def wert(zeile, code, idx):
    if code not in idx:
        return None
    v = zeile[idx[code]]
    return None if v in (None, "") else v

def zahlen(code, idx, daten):
    out = []
    for z in daten:
        v = wert(z, code, idx)
        if v is not None:
            try:
                out.append(float(v))
            except (TypeError, ValueError):
                pass
    return out

def kennwerte(code, idx, daten):
    v = zahlen(code, idx, daten)
    if not v:
        return None
    return len(v), round(st.mean(v), 2), round(st.pstdev(v), 2)

def skalenwert(items, idx, daten):
    pro_person = []
    for z in daten:
        werte = [wert(z, c, idx) for c in items]
        if all(w is not None for w in werte):
            pro_person.append(st.mean(float(w) for w in werte))
    if not pro_person:
        return None
    return len(pro_person), round(st.mean(pro_person), 2), round(st.pstdev(pro_person), 2)

def verteilung(code, idx, daten):
    """Antwortverteilung 1 bis 5 eines Likert-Items."""
    v = zahlen(code, idx, daten)
    c = Counter(int(x) for x in v)
    return [c.get(k, 0) for k in (1, 2, 3, 4, 5)], len(v)

def cronbach_alpha(items, idx, daten):
    """Cronbachs Alpha einer Skala. Es gehen nur Personen ein, die alle Items
    beantwortet haben (listenweiser Ausschluss). Gibt (n, alpha) zurueck."""
    matrix = []
    for z in daten:
        werte = [wert(z, c, idx) for c in items]
        if all(w is not None for w in werte):
            matrix.append([float(w) for w in werte])
    k = len(items)
    if len(matrix) < 3 or k < 2:
        return None
    item_var = [st.pvariance([row[j] for row in matrix]) for j in range(k)]
    total = [sum(row) for row in matrix]
    var_total = st.pvariance(total)
    if var_total == 0:
        return None
    alpha = (k / (k - 1)) * (1 - sum(item_var) / var_total)
    return len(matrix), round(alpha, 2)

def korrelation(code1, code2, idx, daten):
    """Produkt-Moment-Korrelation (Pearson) zweier Items ueber die Personen,
    die beide Items beantwortet haben. Gibt (n, r) zurueck."""
    xs, ys = [], []
    for z in daten:
        a, b = wert(z, code1, idx), wert(z, code2, idx)
        if a is not None and b is not None:
            try:
                xs.append(float(a))
                ys.append(float(b))
            except (TypeError, ValueError):
                pass
    n = len(xs)
    if n < 3:
        return None
    mx, my = st.mean(xs), st.mean(ys)
    num = sum((x - mx) * (y - my) for x, y in zip(xs, ys))
    den = (sum((x - mx) ** 2 for x in xs) * sum((y - my) ** 2 for y in ys)) ** 0.5
    if den == 0:
        return None
    return n, round(num / den, 2)

# ----------------------------------------------------------------------
# 3 Abbildungen (werden im Speicher erzeugt, keine Bilddatei auf der Platte)
# ----------------------------------------------------------------------

def abb1_skalen(idx, daten):
    """Balkendiagramm der vier Kurzskalen. Gibt einen PNG-Puffer zurueck."""
    name_map = {
        "S1": "S1\nAttraktivität",
        "S2": "S2\nNutzungsintention",
        "S3": "S3\nVerständlichkeit",
        "S4": "S4\nGamification",
    }
    namen, mittel, streu = [], [], []
    for name, items in SKALEN.items():
        k = skalenwert(items, idx, daten)
        if k:
            namen.append(name_map.get(name.split()[0], name.split()[0]))
            mittel.append(k[1])
            streu.append(k[2])
    if not namen:
        return None

    fig, ax = plt.subplots(figsize=(7, 4))
    bars = ax.bar(namen, mittel, yerr=streu, capsize=6, color=HFU_FARBE, edgecolor="black", width=0.6)
    ax.set_ylim(1, 5)
    ax.set_ylabel("Mittelwert (1–5)", fontsize=12)
    ax.axhline(3, color=GRAU, linestyle="--", linewidth=1.5)
    ax.text(0.5, 3.05, "Skalenmitte (3)", color=GRAU, fontsize=9)
    ax.spines["top"].set_visible(False)
    ax.spines["right"].set_visible(False)
    for bar, m in zip(bars, mittel):
        ax.text(bar.get_x() + bar.get_width() / 2., bar.get_height() + 0.1,
                f"{m:.2f}", ha="center", va="bottom", fontweight="bold")
    plt.tight_layout()
    buf = BytesIO()
    plt.savefig(buf, format="png", dpi=300)
    plt.close(fig)
    buf.seek(0)
    return buf

def abb2_items(idx, daten):
    """Horizontales Balkendiagramm der Einzelitems. Gibt einen PNG-Puffer zurueck."""
    codes = ["A201", "A202", "A203", "A204", "A205", "A206", "A207", "A208"]
    labels = ["F5", "F6", "F7", "F8", "F8a", "F8b", "F9", "F10"]
    werte = [kennwerte(c, idx, daten)[1] for c in codes if kennwerte(c, idx, daten)]
    if not werte:
        return None

    fig, ax = plt.subplots(figsize=(7, 4))
    farben = [HFU_FARBE if v >= 4.0 else HELL if v < 3.5 else MEDIUM for v in werte]
    bars = ax.barh(range(len(werte))[::-1], werte, color=farben, edgecolor="black", height=0.7)
    ax.set_yticks(range(len(werte))[::-1])
    ax.set_yticklabels(labels, fontsize=12)
    ax.set_xlim(1, 5)
    ax.set_xlabel("Mittelwert (1–5)", fontsize=12)
    ax.axvline(3, color=GRAU, linestyle="--")
    for bar in bars:
        w = bar.get_width()
        ax.text(w + 0.05, bar.get_y() + bar.get_height() / 2,
                f"{w:.2f}", va="center", fontweight="bold", fontsize=11)
    ax.spines["top"].set_visible(False)
    ax.spines["right"].set_visible(False)
    plt.tight_layout()
    buf = BytesIO()
    plt.savefig(buf, format="png", dpi=300)
    plt.close(fig)
    buf.seek(0)
    return buf

# ----------------------------------------------------------------------
# 4 Word-Ergebnisdokument
# ----------------------------------------------------------------------

def word_bericht():
    """Erstellt das Word-Dokument mit allen deskriptiven Kennwerten und den
    beiden eingebetteten Abbildungen."""
    from docx import Document
    from docx.shared import Pt, Cm, RGBColor
    from docx.enum.text import WD_ALIGN_PARAGRAPH
    from docx.enum.table import WD_TABLE_ALIGNMENT
    from docx.oxml.ns import qn
    from docx.oxml import OxmlElement

    idx, daten = lade_daten(DATEI)
    HFU = RGBColor(0x00, 0x89, 0x3A)

    doc = Document()
    normal = doc.styles["Normal"]
    normal.font.name = "Arial"
    normal.font.size = Pt(11)
    for s in doc.sections:
        s.left_margin = s.right_margin = Cm(2.5)
        s.top_margin = s.bottom_margin = Cm(2.0)

    def ueberschrift(text, groesse=14, oben=14):
        p = doc.add_paragraph()
        p.paragraph_format.space_before = Pt(oben)
        p.paragraph_format.space_after = Pt(6)
        r = p.add_run(text)
        r.bold = True
        r.font.size = Pt(groesse)
        r.font.color.rgb = HFU
        return p

    def absatz(text, kursiv=False, klein=False):
        p = doc.add_paragraph()
        p.paragraph_format.space_after = Pt(6)
        r = p.add_run(text)
        r.italic = kursiv
        if klein:
            r.font.size = Pt(9)
            r.font.color.rgb = RGBColor(0x55, 0x55, 0x55)
        return p

    def _shade(cell, hexfarbe):
        tcPr = cell._tc.get_or_add_tcPr()
        shd = OxmlElement("w:shd")
        shd.set(qn("w:val"), "clear")
        shd.set(qn("w:color"), "auto")
        shd.set(qn("w:fill"), hexfarbe)
        tcPr.append(shd)

    def _gruene_raender(table, hexfarbe):
        tblPr = table._tbl.tblPr
        borders = OxmlElement("w:tblBorders")
        for kante in ("top", "left", "bottom", "right", "insideH", "insideV"):
            e = OxmlElement("w:" + kante)
            e.set(qn("w:val"), "single")
            e.set(qn("w:sz"), "4")
            e.set(qn("w:space"), "0")
            e.set(qn("w:color"), hexfarbe)
            borders.append(e)
        tblPr.append(borders)

    def tabelle(kopf, zeilen):
        t = doc.add_table(rows=1, cols=len(kopf))
        t.style = "Table Grid"
        t.alignment = WD_TABLE_ALIGNMENT.LEFT
        for i, k in enumerate(kopf):
            c = t.rows[0].cells[i]
            c.text = ""
            _shade(c, HFU_HEX)
            run = c.paragraphs[0].add_run(k)
            run.bold = True
            run.font.size = Pt(10)
            run.font.color.rgb = RGBColor(0xFF, 0xFF, 0xFF)
        for r, zeile in enumerate(zeilen):
            cells = t.add_row().cells
            for i, val in enumerate(zeile):
                cells[i].text = ""
                if r % 2 == 1:
                    _shade(cells[i], HFU_HELL)
                run = cells[i].paragraphs[0].add_run(str(val))
                run.font.size = Pt(10)
        _gruene_raender(t, HFU_HEX)
        doc.add_paragraph().paragraph_format.space_after = Pt(2)
        return t

    # --- Titel ---
    titel = doc.add_paragraph()
    r = titel.add_run("Pretest RESONANZ – Deskriptive Auswertung")
    r.bold = True
    r.font.size = Pt(18)
    r.font.color.rgb = HFU
    stand = datetime.date.today().strftime("%d.%m.%Y")
    absatz(f"Automatisch erzeugtes Ergebnisdokument · Stand: {stand}", kursiv=True, klein=True)
    absatz("Grundlage: unveraenderter SoSci-Survey-Export. Fehlende Werte wurden nicht "
           "ersetzt (keine Imputation); die Fallzahl (n) variiert daher je Kennwert. "
           "Die Streuung ist als Standardabweichung der beobachteten Faelle angegeben. "
           "Die Auswertung ist deskriptiv (Konzeptpruefung, keine Hypothesentestung).",
           klein=True)

    # --- 1 Fallzahlen ---
    ueberschrift("1  Fallzahlen")
    gesamt = len(daten)
    fertig = sum(1 for z in daten if str(wert(z, "FINISHED", idx)) == "1")
    tabelle(["Kennzahl", "Wert"], [
        ["Aufrufe insgesamt", gesamt],
        ["Vollstaendige Bearbeitungen", fertig],
        ["Auswertbar Soziodemografie (Block 1)", len(zahlen("A101", idx, daten))],
        ["Auswertbar Akzeptanz (Block 2)", len(zahlen("A201", idx, daten))],
        ["Auswertbar Verstaendlichkeit (Block 3)", len(zahlen("A301", idx, daten))],
    ])
    absatz("Die Fallzahl unterscheidet sich je Block, weil Teilnehmende an "
           "verschiedenen Stellen abgebrochen haben.", klein=True)

    # --- 2 Stichprobenbeschreibung ---
    ueberschrift("2  Stichprobenbeschreibung")
    for code, (label, labels) in KATEGORIAL.items():
        v = zahlen(code, idx, daten)
        c = Counter(int(x) for x in v)
        n = len(v)
        zeilen = []
        for k in sorted(labels):
            anzahl = c.get(k, 0)
            anteil = f"{100 * anzahl / n:.1f} %" if n else "–"
            zeilen.append([labels[k], anzahl, anteil])
        absatz(f"{label}  (n = {n})", kursiv=True)
        tabelle(["Auspraegung", "Anzahl", "Anteil"], zeilen)

    # --- 3 Vorerfahrung: genutzte Apps ---
    ueberschrift("3  Vorerfahrung: genutzte Apps und Zufriedenheit")
    apps = []
    personen_mit_app = 0
    for z in daten:
        genannt = [str(wert(z, c, idx)).strip() for c in APP_NENNUNGEN
                   if wert(z, c, idx) is not None and str(wert(z, c, idx)).strip()]
        if genannt:
            personen_mit_app += 1
        apps.extend(genannt)
    app_zaehl = Counter(apps)
    absatz(f"Bereits genutzte Gesundheits-Apps (Freitext, Mehrfachnennung "
           f"moeglich): {len(apps)} Nennungen von {personen_mit_app} Personen.",
           kursiv=True)
    if app_zaehl:
        tabelle(["App", "Nennungen"],
                [[name, anzahl] for name, anzahl in app_zaehl.most_common()])
    else:
        absatz("Keine App-Namen genannt.", klein=True)
    kz = kennwerte(APP_ZUFRIEDENHEIT, idx, daten)
    if kz:
        absatz(f"Zufriedenheit mit bisher genutzten Apps (Skala 1 bis 5): "
               f"M = {kz[1]:.2f}, SD = {kz[2]:.2f}, n = {kz[0]}.", klein=True)

    # --- 4 Einzelitems ---
    ueberschrift("4  Einzelitems (Skala 1 bis 5)")
    zeilen = []
    for code, label in ITEMS.items():
        k = kennwerte(code, idx, daten)
        if k:
            zeilen.append([label, k[0], f"{k[1]:.2f}", f"{k[2]:.2f}"])
    tabelle(["Item", "n", "M", "SD"], zeilen)
    absatz("M = Mittelwert, SD = Standardabweichung. Item F13 (A303) ist negativ "
           "gepolt: ein hoher Wert bedeutet mehr Datenschutz-Bedenken.", klein=True)

    # --- 5 Kurzskalen ---
    ueberschrift("5  Kurzskalen und Reliabilitaet")
    zeilen = []
    for name, items in SKALEN.items():
        k = skalenwert(items, idx, daten)
        a = cronbach_alpha(items, idx, daten)
        if k:
            alpha_txt = f"{a[1]:.2f}" if a else "–"
            zeilen.append([name, " + ".join(items), k[0], f"{k[1]:.2f}", f"{k[2]:.2f}", alpha_txt])
    tabelle(["Skala", "Items", "n", "M", "SD", "Cronbachs α"], zeilen)
    absatz("Skalenbildung zweistufig: zunaechst je Person der Mittelwert ueber die "
           "Items, danach der Mittelwert ueber alle Personen. Eine Person geht nur "
           "ein, wenn sie alle Items der Skala beantwortet hat (listenweiser "
           "Ausschluss). Cronbachs Alpha als Mass der internen Konsistenz; bei den "
           "Zweiitemskalen S2 und S3 nur eingeschraenkt aussagekraeftig, daher "
           "ergaenzend die Interitemkorrelation.", klein=True)

    # Korrelationen inhaltlich verwandter Itempaare
    r_s2 = korrelation("A207", "A208", idx, daten)   # F9 x F10  (= S2)
    r_s3 = korrelation("A301", "A302", idx, daten)   # F11 x F12 (= S3)
    r_ds = korrelation("A303", "A304", idx, daten)   # F13 x F13b
    kzeilen = []
    if r_s2:
        kzeilen.append(["F9 x F10 (S2: Ausprobieren x Dauernutzung)", r_s2[0], f"{r_s2[1]:.2f}"])
    if r_s3:
        kzeilen.append(["F11 x F12 (S3: Funktionsweise x Inhalte)", r_s3[0], f"{r_s3[1]:.2f}"])
    if r_ds:
        kzeilen.append(["F13 x F13b (Bedenken x Tracking bei Nutzen)", r_ds[0], f"{r_ds[1]:.2f}"])
    if kzeilen:
        absatz("Produkt-Moment-Korrelationen inhaltlich verwandter Itempaare:", kursiv=True)
        tabelle(["Itempaar", "n", "r"], kzeilen)
        absatz("Die Korrelationen dienen ausschliesslich der Einordnung deskriptiver "
               "Befunde, nicht der Hypothesentestung.", klein=True)

    # --- 6 Antwortverteilungen ---
    ueberschrift("6  Antwortverteilungen")
    zeilen = []
    for code, label in ITEMS.items():
        if code in ("A103", "A104"):
            continue
        v, n = verteilung(code, idx, daten)
        zeilen.append([label, v[0], v[1], v[2], v[3], v[4], n])
    tabelle(["Item", "1", "2", "3", "4", "5", "n"], zeilen)
    absatz("Absolute Haeufigkeiten je Antwortstufe (1 = trifft ueberhaupt nicht zu "
           "bis 5 = trifft voll und ganz zu).", klein=True)

    # --- 7 Abbildungen (direkt eingebettet) ---
    ueberschrift("7  Abbildungen")
    for buf, titeltext in (
        (abb1_skalen(idx, daten), "Abbildung 1: Kurzskalen im Ueberblick"),
        (abb2_items(idx, daten), "Abbildung 2: Einzelitems des Akzeptanzblocks"),
    ):
        if buf is not None:
            absatz(titeltext, kursiv=True)
            doc.add_picture(buf, width=Cm(15))
            doc.paragraphs[-1].alignment = WD_ALIGN_PARAGRAPH.CENTER

    # --- 8 Offene Antworten ---
    ueberschrift("8  Offene Antworten")
    absatz("Ungefilterte Freitextantworten fuer die anschliessende qualitative "
           "Codierung. Rechtschreibung und Formulierung im Original.", klein=True)
    for code, label in OFFEN.items():
        antworten = []
        for z in daten:
            v = wert(z, code, idx)
            if v is not None and str(v).strip() not in ("", "-", "/", "?", "??"):
                antworten.append(str(v).strip())
        absatz(f"{label}  ({len(antworten)} Antworten)", kursiv=True)
        for a in antworten:
            p = doc.add_paragraph(style="List Number")
            p.paragraph_format.space_after = Pt(0)
            run = p.add_run(a)
            run.font.size = Pt(10)

    doc.save(WORD_DATEI)
    print(f"-> {WORD_DATEI} gespeichert ({os.path.abspath(WORD_DATEI)}).")

# ----------------------------------------------------------------------
# Startpunkt
# ----------------------------------------------------------------------

if __name__ == "__main__":
    try:
        idx, daten = lade_daten(DATEI)
        print("\n--- AUSWERTUNG STARTET ---")
        print(f"Aufrufe insgesamt: {len(daten)}")
        print(f"Vollstaendige Bearbeitungen: "
              f"{sum(1 for z in daten if str(wert(z, 'FINISHED', idx)) == '1')}")
        print("\nCronbachs Alpha je Skala:")
        for name, items in SKALEN.items():
            a = cronbach_alpha(items, idx, daten)
            if a:
                print(f"  {name}: alpha = {a[1]:.2f} (n = {a[0]})")
        print("Korrelationen:")
        for lab, c1, c2 in [("F9 x F10 ", "A207", "A208"),
                            ("F11 x F12", "A301", "A302"),
                            ("F13 x F13b", "A303", "A304")]:
            r = korrelation(c1, c2, idx, daten)
            if r:
                print(f"  {lab}: r = {r[1]:.2f} (n = {r[0]})")
        word_bericht()
        print("\n--- Erfolgreich abgeschlossen ---")
    except Exception:
        print("\n" + "!" * 50)
        print("FEHLER AUFGETRETEN:")
        traceback.print_exc()
        print("!" * 50)

    input("\nDrücke die Enter-Taste, um das Fenster zu schließen...")
